"""Portable CPU entrypoints."""
